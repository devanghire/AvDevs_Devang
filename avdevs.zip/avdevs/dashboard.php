<?php
require 'database.php';
session_start();
$usersList = array();
if (!empty($_SESSION['user_data'])) {

    $sqlForSelect = "SELECT * FROM users";

    if (mysqli_query($conn, $sqlForSelect)) {
        $result = $conn->query($sqlForSelect);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $usersList[] = $row;
            }
        } else {
            $echo  = '<h3 class="text-center">No Data Found </h3>';
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
} else {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Userform</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
</head>

<body>

    <style>
        .layout {
            margin-left: 10%;
            margin-right: 10%;
            margin-top: 8%;
            padding: 10px, 10px;
        }

        .imageFixSize {
            max-height: 10%;
            max-width: 20%;
        }

        .error {
            color: red;
        }
    </style>

    <div class="container">

        <div align="center">
            <h2>Dashboard</h2>
        </div>

        <div class="layout">
            <div style="padding: 20px;border: 1px solid lightgray;">
                <div>
                    <table class="table table-border table-responsive">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Document</th>
                                <th>Created date</th>

                            </tr>
                        </thead>
                        <tbody id="tbody">
                            <?php if (!empty($usersList)) {
                                foreach ($usersList as $value) { ?>
                                    <tr>
                                        <td><?php echo $value['id']; ?></td>
                                        <td><?php echo $value['first_name']; ?></td>
                                        <td><?php echo $value['last_name']; ?></td>
                                        <td><?php echo $value['email']; ?></td>
                                        <td class="text-center imageFixSize"><img src="<?php echo "uploads/" . $value['document']; ?>" height="30%" width="40%" alt="Document not found"></td>
                                        <td><?php echo $value['created_at']; ?></td>
                                    </tr>
                            <?php }
                            } ?>
                        </tbody>

                    </table>
                    <div> <a href="logout.php" class="cl_all btn btn-primary">logout</a></div>

                </div>
            </div>
        </div>
    </div>
</body>

</html>