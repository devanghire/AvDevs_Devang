<?php
require 'database.php';
session_start();
if(!isset($_SESSION['user_data'])){
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $password = !empty($password)?sha1($password):"";

        $sqlForSelect = "SELECT * FROM users WHERE email = '".$email."' and  password = '".$password ."'";

        if (mysqli_query($conn, $sqlForSelect)) {   
            $result = $conn->query($sqlForSelect);
            if ($result->num_rows > 0) {
                $_SESSION['user_data'] = $result->fetch_assoc();
                header("Location: dashboard.php");
                exit();
            }else{
                echo '<h3 class="text-center errormsg">Oops!! Wrong Email Or Password</h3>';
            }
        }else{
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}else{
    header("Location: dashboard.php");
    exit();
}
if (isset($_SESSION['success_message'])) {
    echo '<h3 class="text-center success">'. $_SESSION['success_message'] .'</h3>';
    unset($_SESSION['success_message']);
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Userform</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
</head>
<body>

<style>

    .layout
    {
        margin-left: 30%;
        margin-right: 30%;
        margin-top: 8%;
        padding: 10px,10px;
    }
    .error
    {
        color:red;
    }
    .success{
        color: green;
    }
</style>

<div class="container">

    <div align="center">
        <h2>Login</h2>
    </div>
    
    <div class="layout">
        <div style="padding: 20px;border: 1px solid lightgray;">
            <form method="post" class="loginForm" id="loginForm">
               
                <div class="form-group">
                    <label for="email">Email</label>*
                    <input type="email" class="form-control" id="email" name="email" required autocomplete="off" >
                </div>

                 <div class="form-group">
                    <label for="password">Password</label>*
                    <input type="password" class="form-control" id="password" name="password" required autocomplete="off">
                </div>

                <div class="form-group">
                    <input type="submit" id="submit" class="btn btn-primary">
                    <input type="button" id="reset" class="btn btn-primary" value="Reset">
                </div>
                <div class="form-group">
                    <a href="register.php">Switch to register</a>
                </div>

            </form>
        </div>
    </div>
</div>

<script>

    $(document).ready(function(){

        $("#email").focus();
        $("#reset").click(function() {
            $("input[type=text] , input[type=email] , input[type=password]").val("");
            $(".errormsg").text("");
        });

        $('#loginForm').validate({

            rules: {
                email: {
                    required: true,
                    email:true,

                },
                password: {
                    required: true,
                },
            },
            messages: {
                email: {
                    required: "Please Enter Email"

                },
                password: {
                    required: "Please Enter Password"

                },

            },
        });
       
    });
</script>

</body>
</html>

