<?php
require 'database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = (isset($_POST['firstname']) && !empty($_POST['firstname'])) ? $_POST['firstname'] : "";
    $lastname = (isset($_POST['lastname']) && !empty($_POST['lastname'])) ? $_POST['lastname'] : "";
    $email = (isset($_POST['email']) && !empty($_POST['email'])) ? $_POST['email'] : "";
    $password = (isset($_POST['password']) && !empty($_POST['password'])) ? $_POST['password'] : "";
    if (!empty($email) && !empty($password)) {
        $password = sha1($password);
        $datetime = date('Y-m-d h:i:s');
        $fileName = "";

        if (isset($_FILES['document']['name']) && !empty($_FILES['document']['name'])) {
            $folderName = "uploads/";
            if (!is_dir($folderName)) {
                mkdir($folderName, 0777, true);
            }
            $fileName = $_FILES['document']['name'];
            $fileMeta = $folderName . basename($fileName);
            $allowedTypes = ['jpg', 'png', 'gif', 'pdf'];
            $fileExtension = strtolower(pathinfo($fileMeta, PATHINFO_EXTENSION));
            if (!in_array($fileExtension, $allowedTypes)) {
                die("Error: Only JPG, PNG, GIF, and PDF files are allowed.");
            }
            if (!move_uploaded_file($_FILES['document']['tmp_name'], $fileMeta)) {
                echo "Error: There was an issue uploading your file.";
                die;
            }
        }

        $sql = 'INSERT INTO users (`first_name`, `last_name`, `email`,`document` ,`password`,`created_at`,`updated_at`) VALUES ("' . $firstname . '", "' . $lastname . '", "' . $email . '","' . $fileName . '","' . $password . '","' . $datetime . '","' . $datetime . '")';
        if (mysqli_query($conn, $sql)) {
            session_start();
            $_SESSION['success_message'] ="Register successfully"; 
            header("Location: index.php");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        mysqli_close($conn);
    } else {
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Userform</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
</head>

<body>

    <style>
        .layout {
            margin-left: 30%;
            margin-right: 30%;
            margin-top: 8%;
            padding: 10px, 10px;
        }

        .error {
            color: red;
        }
    </style>
<!-- onsubmit="validateForm(event)" -->
    <div class="container">

        <div align="center">
            <h2>Register Form</h2>
        </div>

        <div class="layout">
            <div style="padding: 20px;border: 1px solid lightgray;">
                <div id="error_message" class="error"></div>
                <form method="post" enctype="multipart/form-data" id="registerForm">
                    <div class="form-group">
                        <label for="firstname">First Name</label>*
                        <input type="text" class="form-control" id="firstname" name="firstname">
                    </div>

                    <div class="form-group">
                        <label for="lastname">Last Name</label>
                        <input type="text" class="form-control" id="lastname" name="lastname">
                    </div>

                    <div class="form-group">
                        <label for="file">Document</label>
                        <input type="file" class="form-control" id="document" name="document">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>*
                        <input type="email" class="form-control" id="email" name="email">
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>*
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                    <div class="form-group">
                        <label for="passwordtwo">confirm Password</label>*
                        <input type="password" class="form-control" id="confirmpassword" name="confirmpassword">
                    </div>

                    <div class="form-group">
                        <input type="submit" id="submit" class="btn btn-primary">
                        <input type="button" id="reset" class="btn btn-primary" value="Reset">
                    </div>

                    <div class="form-group">
                        <a href="index.php">Switch to login</a>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {

            $("#firstname").focus();

            $("#firstname,#lastname").focusout(function() {
                let fname = $("#firstname").val();
                let lname = $("#lastname").val();
                $("#firstname").val(fname.charAt(0).toUpperCase() + fname.slice(1));
                $("#lastname").val(lname.charAt(0).toUpperCase() + lname.slice(1));
            })
            $("#reset").click(function() {
                $("input[type=text] , input[type=email] , input[type=password],textarea").val("");
                $("#error_message").html("");
            });
        });

        $('#registerForm').validate({
            rules: {
                firstname: {
                    required: true,
                },
                email: {
                    required: true,
                    email: true,
                },
                password: {
                    required: true,
                    rangelength: [5, 10]
                },
                confirmpassword: {
                    equalTo: password

                }
            },
            messages: {
                firstname: {
                    required: "Enter First Name"

                },
                email: {
                    required: "Enter Email Address"

                },
                password: {
                    required: "Enter Password"
                },

            },
        });
    </script>

</body>

</html>